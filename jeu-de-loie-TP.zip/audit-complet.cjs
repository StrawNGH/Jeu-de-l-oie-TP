const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/index.html','utf8');
assert.equal(html,fs.readFileSync(__dirname+'/jeu_de_l_oie_modulaire_le_jardin_des_oies.html','utf8'));
const source=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].at(-1)[1];
const elements=new Map(),tasks=new Map();let serial=0;
const element=()=>({style:{},children:[],classList:{add(){},remove(){},toggle(){}},appendChild(x){this.children.push(x);},setAttribute(){},textContent:'',innerHTML:'',value:'0',checked:false,disabled:false});
const document={getElementById(id){if(!elements.has(id))elements.set(id,element());return elements.get(id);},createElement:element,querySelectorAll:()=>[],querySelector:()=>null};
const c={document,window:{},console,
 setTimeout(fn){const id=++serial;tasks.set(id,{fn,interval:false});return id;},
 setInterval(fn){const id=++serial;tasks.set(id,{fn,interval:true});return id;},
 clearInterval(id){tasks.delete(id);}};
c.drain=()=>{let limit=1000;while(tasks.size){if(--limit<0)throw Error('Temporisations sans fin');for(const [id,t] of [...tasks]){if(!tasks.has(id))continue;if(!t.interval)tasks.delete(id);t.fn();}}};
vm.createContext(c);vm.runInContext(source,c);
vm.runInContext(`
soundEnabled=false;
let seed=123456789;
Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
function verifyState(){
 if(gameState.players.length<2||gameState.players.length>10)throw Error('Nombre équipes');
 if(!gameState.players.every(p=>Number.isInteger(p.position)&&p.position>=1&&p.position<=63&&p.hand.length<=3&&p.skipTurns>=0))throw Error('État invalide');
 if(!gameState.players[gameState.turnIndex])throw Error('Index tour');
}
// Exercise actual rendering functions once, including real victory and reset.
regenerateNewGame();drain();renderAll();
gameState.players[0].position=63;triggerVictory(gameState.players[0]);
const wonState=JSON.stringify(gameState);
handleRollDice();playPlayerActionCard(0);drawChanceCardManual();drain();
if(JSON.stringify(gameState)!==wonState)throw Error('Action possible après victoire');
closeVictoryAndReset();drain();
if(gameState.finished||gameState.players.some(p=>p.position!==1))throw Error('Rejouer après victoire');
// Pure actions: every position, every team count, both end-of-board rules.
let actionCases=0;
for(let n=2;n<=10;n++)for(const bounce of [false,true])for(let pos=1;pos<=63;pos++)for(const action of Object.values(ACTION_REGISTRY)){
 const state={players:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Équipe '+i,position:i===0?pos:1+(i*7)%62,skipTurns:0,hand:[]})),board:[],maxCell:63,config:{exactBounce:bounce}};
 const result=action.execute(state,'p0',{source:'CELL',lastRoll:12,cellNumber:pos});
 if(!result?.gameState||typeof result.message!=='string')throw Error('Contrat '+action.id);
 if(!result.gameState.players.every(p=>Number.isInteger(p.position)&&p.position>=1&&p.position<=63))throw Error('Bornes '+action.id);
 actionCases++;
}
console.log('OK : '+actionCases+' cas d’actions (2 à 10 équipes, 63 positions, rebond activé/désactivé).');
// Keep the real dice, move, action, chance, end-turn and victory functions.
renderAll=()=>{};showToast=()=>{};playSoundEffect=()=>{};hideLiveActionBanner=()=>{};showLiveActionBanner=()=>{};
const defaults=Object.fromEntries(Object.entries(ACTION_REGISTRY).map(([id,a])=>[id,a.weight]));
let completed=0,rolls=0;
for(let n=2;n<=10;n++)for(const dice of [1,2])for(const bounce of [true,false])for(const coverage of [0,100])for(const drop of [0,100])for(let repeat=0;repeat<2;repeat++){
 setupDraft.playerCount=n;applySetupDraftToPlayersList();
 Object.values(ACTION_REGISTRY).forEach(a=>a.weight=defaults[a.id]);
 gameState.config={diceCount:dice,exactBounce:bounce,boardCoverageProb:coverage,cardDropProb:drop};
 regenerateNewGame();drain();
 if(coverage===0&&gameState.board.some(c=>c.actionId))throw Error('Couverture 0');
 if(coverage===100&&gameState.board.slice(1,-1).some(c=>!c.actionId))throw Error('Couverture 100');
 let moves=0;
 while(!gameState.finished && moves++<20000){
   const active=gameState.players[gameState.turnIndex];
   if(active.hand.length&&Math.random()<0.4)playPlayerActionCard(0);
   let depth=0;while(pendingChanceAction&&depth++<20){confirmChanceCardExecution();drain();}
   if(pendingChanceAction)throw Error('Chance sans fin');
   if(!gameState.finished){handleRollDice();drain();rolls++;}
   depth=0;while(pendingChanceAction&&depth++<20){confirmChanceCardExecution();drain();}
   verifyState();
 }
 if(!gameState.finished)throw Error('Victoire absente');
 completed++;
}
console.log('OK : '+completed+' parties complètes via le véritable lancer de dés, '+rolls+' tours ; tous les effectifs 2–10, 1/2 dés, avec/sans rebond, probabilités 0/100 %.');
regenerateNewGame();Object.values(ACTION_REGISTRY).forEach(a=>a.weight=0);
generateDynamicBoard();dealInitialPlayerCards();
if(gameState.board.some(c=>c.actionId)||gameState.players.some(p=>p.hand.length))throw Error('Poids nuls');
openChanceCardModal(gameState.players[0].id);verifyState();
console.log('OK : aucun poids actif, rendu initial, victoire réelle, blocage après victoire et redémarrage.');
`,c,{timeout:120000});
