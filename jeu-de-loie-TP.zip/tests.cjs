const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync(__dirname + '/index.html', 'utf8');
const scripts = [...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]).filter(s => s.trim());
for (const script of scripts) new vm.Script(script);
const ctx = {window: {}, console, document: {querySelectorAll: () => []}};
vm.createContext(ctx);
vm.runInContext(scripts.at(-1), ctx);
vm.runInContext(`
renderSetupPlayerCountTabs=()=>{}; renderSetupPlayerNameInputs=()=>{};
for(const n of [2,7,10]) {
  selectSetupPlayerCount(n); applySetupDraftToPlayersList();
  if(gameState.players.length!==n) throw Error('Effectif');
  if(new Set(gameState.players.map(p=>p.color)).size!==n) throw Error('Couleurs');
}
for(const [input,expected] of [[1,2],[11,10],[NaN,2],[3.9,3]]) {
  selectSetupPlayerCount(input);
  if(setupDraft.playerCount!==expected) throw Error('Bornes');
}
for(const n of [2,10]) for(const position of [1,4,30,63]) {
  const state={players:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Équipe '+i,position,hand:[]})),maxCell:63};
  const r=ACTION_REGISTRY.recul_collectif.execute(state,'p0',{});
  if(r.gameState.players[0].position!==Math.max(1,position-n)) throw Error('Recul');
  if(r.extraTurn||r.triggerChanceCard) throw Error('Effets');
  if(state.players[1].position!==position) throw Error('Autre équipe');
}
if(!ACTION_REGISTRY.recul_collectif.canBePlayerCard||!ACTION_REGISTRY.recul_collectif.canBeOnBoard) throw Error('Intégration');
`, ctx);
if ((html.match(/data-count-btn=/g)||[]).length !== 9) throw Error('Boutons');
console.log('OK : syntaxe, équipes 2/7/10, couleurs, saisies invalides, huit scénarios de recul, intégration cartes/plateau.');
const elements = new Map();
ctx.document.getElementById = id => {
  if (!elements.has(id)) elements.set(id, {classList:{add(){},remove(){},toggle(){}},style:{},textContent:'',innerHTML:'',disabled:false});
  return elements.get(id);
};
const timers = [];
ctx.setInterval = fn => {timers.push(fn); return timers.length;};
ctx.clearInterval = () => {};
ctx.setTimeout = fn => {timers.push(fn); return timers.length;};
vm.runInContext(`
if(escapeHtml('<img "x">&')!=='&lt;img &quot;x&quot;&gt;&amp;') throw Error('Échappement');
renderAll=()=>{}; playSoundEffect=()=>{}; showToast=()=>{};
showLiveActionBanner=()=>{}; hideLiveActionBanner=()=>{};
selectSetupPlayerCount(2); applySetupDraftToPlayersList(); regenerateNewGame();
gameState.config.cardDropProb=0;
gameState.players[0].skipTurns=1; gameState.players[0].hand=['double_roll'];
playPlayerActionCard(0);
if(gameState.players[0].hand.length!==1||gameState.players[0].position!==1) throw Error('Carte pendant repos');
handleRollDice();
if(gameState.turnIndex!==1||gameState.players[0].skipTurns!==0) throw Error('Tour passé');
regenerateNewGame();
handleRollDice();
regenerateNewGame();
`,ctx);
// Old animation callbacks must leave the new game untouched.
for (const timer of timers.splice(0)) for (let i=0;i<8;i++) timer();
vm.runInContext(`
if(gameState.players.some(p=>p.position!==1)||gameState.turnIndex!==0||isRolling) throw Error('Lancer périmé');
gameState.board[4].actionId='recul_collectif';
isRolling=true; movePlayerAndResolveCell(gameState.players[0],4);
regenerateNewGame();
`,ctx);
for(const timer of timers.splice(0)) timer();
vm.runInContext(`
if(gameState.turnIndex!==0||gameState.players.some(p=>p.position!==1)) throw Error('Action périmée');
gameState.board.forEach(c=>c.actionId=null);
gameState.players[0].position=61;
movePlayerAndResolveCell(gameState.players[0],5);
if(gameState.players[0].position!==60) throw Error('Rebond');
let winner=null; triggerVictory=p=>{winner=p.id;};
gameState.turnIndex=0; gameState.players[0].position=61;
movePlayerAndResolveCell(gameState.players[0],2);
if(winner!==gameState.players[0].id) throw Error('Victoire');
pendingChanceAction={};
const before=gameState.players[0].hand.length;
playPlayerActionCard(0); handleRollDice();
if(isRolling||gameState.players[0].hand.length!==before) throw Error('Carte Chance en attente');
regenerateNewGame();
if(pendingChanceAction!==null) throw Error('Réinitialisation Chance');
gameState.config.cardDropProb=0;
gameState.players[0].hand=['replay'];
playPlayerActionCard(0);
gameState.board.forEach(c=>c.actionId=null);
movePlayerAndResolveCell(gameState.players[0],2);
if(gameState.turnIndex!==0||gameState.extraRolls!==0) throw Error('Bonus carte Oie');
movePlayerAndResolveCell(gameState.players[0],2);
if(gameState.turnIndex!==1) throw Error('Fin bonus carte Oie');
`,ctx);
console.log('OK : échappement HTML, tour passé, annulation des anciens lancers/actions, rebond, victoire, verrouillage Chance et redémarrage.');
console.log('OK : carte Oie = un lancer supplémentaire réel, puis passage à l’équipe suivante.');
ctx.document.querySelector = () => null;
vm.runInContext(`
regenerateNewGame();
gameState.players[0].position=20;
const originalRoster=JSON.stringify(gameState.players);
const originalWeight=ACTION_REGISTRY.replay.weight;
beginSettingsEdit();
gameState.players.pop(); gameState.players[0].name='Modification';
ACTION_REGISTRY.replay.weight=0;
switchModal('none');
if(JSON.stringify(gameState.players)!==originalRoster || ACTION_REGISTRY.replay.weight!==originalWeight) throw Error('Annulation paramètres');
regenerateNewGame(); gameState.lastRoll=12;
gameState.players[0].hand=['double_roll'];
playPlayerActionCard(0);
if(gameState.players[0].position!==5) throw Error('Double foulée en main doit donner +4');
const originalPicker=pickWeightedAction;
pickWeightedAction=()=>ACTION_REGISTRY.wind;
// Use an action with a known existing ID regardless of naming in the base.
const safeAction=Object.values(ACTION_REGISTRY).find(a=>a.name.includes('Vent arrière'));
pickWeightedAction=()=>safeAction;
gameState.players[0].hand=['draw_chance'];
playPlayerActionCard(0);
if(!pendingChanceAction?.resumeTurn) throw Error('Origine carte perdue');
confirmChanceCardExecution();
if(gameState.turnIndex!==0) throw Error('Chance en main termine le tour');
pickWeightedAction=originalPicker;
`,ctx);
console.log('OK : annulation des paramètres, bonus +4 indépendant du dé précédent et maintien du tour après une carte Chance en main.');

// Full seeded games through the real move/action/turn functions; only display is stubbed.
ctx.flushGameTimers = () => { for(const fn of timers.splice(0)) fn(); };
vm.runInContext(`
let seed=67891;
Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
let gamesCompleted=0;
for(const teamCount of [2,10]) for(let game=0;game<10;game++) {
  setupDraft.playerCount=teamCount; applySetupDraftToPlayersList(); regenerateNewGame();
  gameState.config.cardDropProb=35; winner=null;
  let turns=0;
  while(!winner && turns++<10000) {
    const p=gameState.players[gameState.turnIndex];
    if(p.skipTurns>0) handleRollDice();
    else {
      if(p.hand.length && Math.random()<0.3) playPlayerActionCard(0);
      let depth=0;
      while(pendingChanceAction && depth++<30) confirmChanceCardExecution();
      if(pendingChanceAction) throw Error('Boucle Chance');
      if(!winner) {
        const active=gameState.players[gameState.turnIndex];
        isRolling=true;
        movePlayerAndResolveCell(active,2+Math.floor(Math.random()*6)+Math.floor(Math.random()*6));
        flushGameTimers();
        depth=0;
        while(pendingChanceAction && depth++<30) confirmChanceCardExecution();
      }
    }
    if(!gameState.players.every(p=>Number.isInteger(p.position)&&p.position>=1&&p.position<=63&&p.hand.length<=3&&p.skipTurns>=0)) throw Error('État invalide en partie');
    if(gameState.turnIndex<0||gameState.turnIndex>=teamCount) throw Error('Équipe active invalide');
  }
  if(!winner) throw Error('Partie sans victoire');
  gamesCompleted++;
}
if(gamesCompleted!==20) throw Error('Parties incomplètes');
`,ctx);
console.log('OK : 20 parties complètes simulées (10 à deux équipes, 10 à dix), avec cartes, actions, tours passés et victoire.');
