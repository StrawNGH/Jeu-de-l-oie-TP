# Le Jardin des équipes — TP jeu de l’oie

## Lancer le jeu
1. Extraire entièrement le ZIP dans un dossier.
2. Ouvrir index.html dans un navigateur récent.
3. Choisir de 2 à 10 équipes et cliquer sur « Lancer la partie ».

Le jeu utilise HTML, CSS et JavaScript sans installation. Une connexion Internet est nécessaire pour Tailwind et les polices. Fermer ou recharger la page efface la partie. Sur téléphone, le menu et le plateau défilent horizontalement.

## Fichiers du dossier
- index.html : jeu complet, point d’entrée conseillé.
- jeu_de_l_oie_modulaire_le_jardin_des_oies.html : copie identique sous le nom du fichier pédagogique.
- plateau jeu oie.png : illustration du dépôt fourni par le professeur.
- CAHIER_DES_CHARGES.md : fonctionnalités, conditions techniques, graphisme, algorithme et action ajoutée.
- CONFORMITE_CONSIGNES.md : comparaison point par point avec les consignes.
- VERIFICATION.md : corrections et historique des vérifications.
- AUDIT_FINAL.md : périmètre, résultats et limites du dernier audit.
- tests.cjs et audit-complet.cjs : tests reproductibles avec Node.js.
- RESULTATS_TESTS.txt : sortie des deux suites exécutées pour cette livraison.
- README_ORIGINE.md : documentation du projet d’origine, conservée pour attribution.
- MANIFESTE_SHA256.json : empreintes des fichiers livrés (hors manifeste lui-même).

## Vérifier le programme
Avec Node.js installé, ouvrir un terminal dans le dossier puis exécuter :

    node tests.cjs
    node audit-complet.cjs

L’audit couvre 13 608 cas d’actions, 288 parties complètes et 17 699 tours dans la suite renforcée, plus les tests de régression. Le moteur et les temporisations sont exécutés automatiquement ; le DOM est simulé. L’interface est contrôlée séparément dans le navigateur.

## Origine et modifications
Base pédagogique : https://github.com/tspriet/VibeOie . Moteur et graphisme conservés, adaptés avec l’aide d’une IA.
Modifications : 2 à 10 équipes avec couleurs distinctes ; action « Marche arrière collective » ; corrections des cartes, des réglages, des redémarrages et de la fin de partie ; adaptation aux petits écrans. La nouvelle action fait reculer l’équipe du nombre d’équipes participantes, avec un minimum en case 1.

## Rendu demandé
Le cours demande l’adresse de ton propre dépôt GitHub. Publier les fichiers de ce dossier dans ton dépôt, puis remettre son URL sur Moodle. Aucun dépôt GitHub personnel ni remise Moodle n’a été effectué. Le ZIP ne remplace pas cette étape.

Relire le cahier des charges et savoir expliquer l’action ajoutée avant de présenter le travail. Le dépôt d’origine ne contient pas de fichier de licence dans la version consultée ; les consignes du cours demandent explicitement de cloner et de modifier cet exemple.
