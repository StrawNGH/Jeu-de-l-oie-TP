# Comparaison avec les consignes du TP

Consignes consultées : livre Moodle « Les IA Génératives pour coder JEU de l'oie », chapitres 464, 466, 467, 468, 471 et 472.

| Consigne | État | Réalisation / preuve |
|---|---|---|
| Partir de l'exemple VibeOie et le personnaliser | Réalisé | Base clonée, origine conservée dans README_ORIGINE.md ; modifications dans les fichiers HTML |
| Choisir entre 2 et 10 équipes | Réalisé | Neuf choix dans la préparation, dix couleurs ; tests 2/7/10 équipes |
| Proposer de lancer le jeu | Réalisé | Bouton « Lancer la partie » |
| Afficher le plateau, les positions et déplacements | Réalisé | Plateau de 63 cases, pions repositionnés, dés animés et historique des déplacements |
| Cartes actions utilisables au choix pendant le tour | Réalisé | Cartes en main, bouton Jouer, trois cartes maximum ; blocage pendant un lancer ou un tour à passer |
| Écrire les fonctionnalités attendues | Réalisé | CAHIER_DES_CHARGES.md |
| Décrire les conditions techniques | Réalisé | HTML/CSS/JavaScript, navigateur local, connexion nécessaire aux styles et polices ; absence de sauvegarde précisée |
| Décrire l'aspect graphique | Réalisé | Ambiance jardin, couleurs, plateau et panneaux décrits dans le cahier des charges |
| Ajouter une action et l'intégrer au moteur | Réalisé | Marche arrière collective, enregistrée via registerGooseAction ; cases, cartes Chance et main |
| Tester les fonctionnalités et les interactions inattendues | Réalisé sur les scénarios documentés | tests.cjs et VERIFICATION.md ; limites, noms spéciaux, réglages, cartes, rebond, victoire et redémarrage |
| Vérifier plusieurs parties successives | Réalisé en simulation | 20 parties complètes déterministes : 10 avec 2 équipes, 10 avec 10 équipes |
| Décomposer le programme et garder un regard critique | Documenté ; à maîtriser personnellement | Algorithme, contrat des actions, explication des modifications et regard critique dans le cahier des charges |
| Modifier le projet dans son propre dépôt et rendre son adresse | À faire | Aucun dépôt GitHub personnel ni dépôt de lien sur Moodle n'a été créé |

## Points à connaître avant le rendu
Le ZIP contient les sources et les documents ; il ne remplace pas l'adresse du dépôt demandée par le professeur. Le travail repose explicitement sur l'exemple fourni et sur l'aide d'une IA. Relire les règles et comprendre l'action ajoutée permet de présenter le projet et d'expliquer les choix.

Les simulations vérifient le moteur avec une interface simulée. Elles ne constituent pas vingt parties jouées manuellement dans un navigateur. L'interface a été contrôlée séparément pour la préparation, les noms et les réglages. Une vérification exhaustive sur tous les écrans et navigateurs n'a pas été réalisée.
