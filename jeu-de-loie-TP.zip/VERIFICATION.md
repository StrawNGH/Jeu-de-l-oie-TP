# Vérification et corrections

## Erreurs corrigées
- Les noms et le journal utilisaient du HTML non échappé. Les caractères spéciaux sont maintenant affichés comme du texte, y compris dans les champs des paramètres.
- Redémarrer pendant un lancer ou avant une action différée pouvait laisser un ancien traitement modifier la nouvelle partie. Chaque traitement vérifie maintenant la révision de la partie ; la réinitialisation libère aussi le lancer et la carte Chance en attente.
- Les cartes de la main et le tirage manuel Chance étaient utilisables pendant un tour à passer. Ils sont maintenant bloqués pendant le repos.
- Une carte Chance en attente ne bloquait pas tous les autres contrôles de jeu. Les fonctions de lancer et de carte vérifient maintenant cette attente.
- La carte Oie jouée depuis la main annonçait un lancer supplémentaire sans le mémoriser. Ce bonus est désormais consommé avant de passer à l'équipe suivante.

## Contrôles
Commande : `node tests.cjs`.

## Audit complémentaire des consignes
- Annuler les paramètres pouvait laisser des modifications dans la partie. Un instantané de la partie et des poids est maintenant restauré à l'annulation ; « Appliquer » valide les changements.
- Ajouter ou enlever une équipe dans les paramètres effaçait les noms en cours de saisie. Ils sont maintenant conservés avant de redessiner les champs.
- Les réglages susceptibles de remplacer les équipes sont bloqués pendant un lancer ou une carte en cours.
- Double foulée en main utilisait parfois le dernier dé d'une autre équipe au lieu du bonus +4 annoncé. Le bonus correspond maintenant à la description.
- Une carte Chance issue de la main faisait passer à l'équipe suivante. Son origine est conservée pour permettre le lancer normal ensuite, y compris si la carte obtenue donne un bonus Oie.

Tests complémentaires réussis : restauration des paramètres, bonus +4, maintien du tour après Chance en main et vingt parties complètes simulées avec graines déterministes. Dix parties utilisent deux équipes et dix utilisent dix équipes ; chacune atteint une victoire, avec contrôle des bornes des positions, des cartes et de l'équipe active.

Contrôle navigateur complémentaire : saisir un nom, ajouter une équipe, vérifier que le nom reste présent puis annuler ; les quatre équipes et noms d'origine sont restaurés.

Tests réussis : syntaxe des scripts, 2/7/10 équipes, couleurs distinctes, bornes et entrées invalides, huit scénarios de l'action personnalisée, échappement HTML, tour à passer, annulation des lancers et actions périmés, rebond, victoire, attente Chance, redémarrage, bonus Oie puis changement d'équipe.

Dans le navigateur : démarrage d'une partie avec un nom contenant des balises et des guillemets ; le nom apparaît littéralement, sans devenir une balise HTML.

Limites : les tests du moteur utilisent un DOM simplifié et des temporisations contrôlées. Ils ne remplacent pas une partie complète à plusieurs ni une vérification sur tous les navigateurs. Le style utilise toujours des ressources Internet et la partie ne persiste pas après rechargement.
