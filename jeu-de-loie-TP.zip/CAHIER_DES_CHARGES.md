# Le Jardin des équipes — Cahier des charges

## Objectif et origine
Créer une variante personnalisable du jeu de l'oie à partir de l'exemple pédagogique https://github.com/tspriet/VibeOie. Le moteur et le graphisme sont issus de cet exemple ; les adaptations de ce TP sont décrites ci-dessous. Ce projet a été préparé avec une IA et doit être relu et compris avant le rendu.

## Fonctionnalités attendues
- Choisir de 2 à 10 équipes et personnaliser leurs noms.
- Donner un pion de couleur distincte à chaque équipe.
- Démarrer une partie sur un circuit de 63 cases ; départ en case 1.
- Lancer un ou deux dés et afficher les déplacements et le journal des événements.
- Alterner les équipes et gérer les tours supplémentaires ou les tours à passer.
- Gagner en atteignant la case 63 ; avec le rebond activé, reculer du surplus si on la dépasse.
- Répartir aléatoirement les cases actions et régler leur fréquence.
- Distribuer des cartes actions utilisables pendant le tour, avec trois cartes maximum en main.
- Recommencer une partie et modifier les participants.
- Étendre le jeu avec des actions respectant le registre existant.

## Action ajoutée
**Marche arrière collective** : l'équipe concernée recule d'autant de cases qu'il y a d'équipes. La position reste au minimum égale à 1. Avec dix équipes, une équipe en case 30 arrive en case 20 ; en case 4, elle revient en case 1. L'action peut être tirée sur le plateau, comme carte Chance ou comme carte en main. Elle ne donne pas de tour supplémentaire et ne déclenche pas une deuxième carte Chance.

## Conditions techniques
HTML, CSS et JavaScript, sans compilation ni serveur applicatif. Ouvrir index.html dans un navigateur récent sous Windows, macOS ou Linux. Internet est nécessaire pour le style Tailwind et les polices externes hérités de l'exemple. L'état reste en mémoire : fermer ou recharger la page réinitialise la partie. Le jeu se joue à plusieurs sur le même écran.

## Interface
Conserver l'ambiance jardin de l'exemple : fond crème, vert forêt, couleurs terre cuite, plateau en spirale, pions colorés. Afficher le plateau, le tour courant, les cartes en main, la liste des équipes et l'historique. Utiliser une fenêtre de préparation avec les neuf choix de 2 à 10 équipes.

## Décomposition et algorithme
1. Saisir et borner le nombre d'équipes, récupérer les noms, attribuer les couleurs.
2. Construire le plateau et distribuer les cartes initiales.
3. Pour l'équipe active : gérer un éventuel tour à passer, autoriser une carte, puis lancer les dés.
4. Calculer la position, gérer le rebond, appliquer l'action de la case et vérifier la victoire.
5. Mettre à jour l'écran et l'historique puis passer à l'équipe suivante, sauf tour supplémentaire.

Le registre ACTION_REGISTRY sépare les règles des actions et leur affichage. Chaque action reçoit gameState, playerId et context ; elle retourne gameState, message, extraTurn et triggerChanceCard. La nouvelle action modifie uniquement la position de l'équipe ciblée. Elle est enregistrée avant l'initialisation du plateau pour participer aux tirages.

## Demande de modification utilisée
« En conservant le moteur, les cartes et le plateau existants, permettre de 2 à 10 équipes avec des couleurs distinctes. Ajouter une action compatible avec registerGooseAction : reculer d'autant de cases qu'il y a d'équipes, sans descendre sous la case 1. Préserver les autres équipes et tester les limites. »

## Regard critique
L'exemple ne respectait pas directement la limite de dix équipes : il fallait modifier les boutons, les bornes, les noms et la palette. Vérifier seulement l'apparence n'aurait pas suffi. L'IA facilite la modification, mais il faut contrôler les effets sur les cartes, les équipes et les positions limites. Les tests automatisés ciblent les changements ; ils ne prouvent pas à eux seuls le bon fonctionnement de toutes les règles héritées.
