# Audit final du livrable

## Résultats
- Suite de régression : syntaxe, équipes, noms, cartes, redémarrages, paramètres, bonus Oie et vingt parties simulées.
- Suite renforcée : 13 608 exécutions d’actions couvrant 63 positions, 2 à 10 équipes et les deux modes de rebond.
- 288 parties complètes, soit 17 699 tours, via les véritables fonctions de lancer, déplacement, action, carte Chance, fin de tour et victoire ; affichage simulé pendant les longues séries.
- Combinaisons : 2 à 10 équipes, 1 ou 2 dés, rebond activé ou non, couverture et distribution de cartes à 0 % ou 100 %, deux répétitions déterministes par combinaison.
- Vérification des positions entre 1 et 63, de la limite de trois cartes, des tours à passer, de l’équipe active et de la présence d’une victoire.
- Tous les poids à zéro : aucune action ni carte distribuée, pas de plantage.
- Vérification du rendu initial, de la victoire réelle, du blocage après victoire et du redémarrage.
- Contrôle navigateur : lancement à dix équipes, lancer réel, écran de 390 pixels, menu et plateau défilants, pions regroupés.

## Dernières corrections
La fin de partie verrouille maintenant les commandes jusqu’au redémarrage. Les pions nombreux sont répartis sur deux rangées. Les commandes mobiles restent accessibles par défilement, sans élargir la page. Les règles décrivent le mode sans rebond et l’action personnalisée.

## Archive
Le ZIP est construit avec une liste explicite de fichiers, sans historique Git, identifiants, fichiers temporaires ni dépendances installées. Chaque fichier est comparé octet par octet avec sa source après extraction. Les deux suites sont relancées depuis cette extraction ; leurs résultats sont contrôlés avant livraison. Le manifeste SHA-256 permet de vérifier le contenu.

## Limites et rendu
Les tests passent dans les configurations documentées ; cela ne constitue pas une preuve d’absence universelle de bugs. Les règles personnalisées saisies ultérieurement dans l’éditeur ne sont pas couvertes. Les styles et les polices nécessitent Internet, et la partie reste en mémoire. La vérification n’a pas porté sur tous les navigateurs et appareils.

Le ZIP contient les éléments locaux du TP. Le dépôt GitHub personnel et la remise de son adresse sur Moodle restent à effectuer ; une URL personnelle ne peut pas être remplacée par un fichier dans l’archive.
